const admin = require("firebase-admin");
const serviceAccount = require("./serviceKey.json");
const nodemailer= require("nodemailer")
var transporter = nodemailer.createTransport({
  host: "smtp.zoho.com",
  port: 465,
  secure: true, //ssl
  auth: {
    user: "chnouman49@zohomail.com",
    pass: "huGGJqKhATDF",
  },
});

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL:
    "https://scrapping-proj-default-rtdb.asia-southeast1.firebasedatabase.app/", // Replace with your Firebase project's database URL
});
const db = admin.database();
const ref = db.ref("/");
const scraperObject = {
  url: "https://online.immi.gov.au/evo/firstParty",
  async scraper(browser) {
    let page = await browser.newPage();
    console.log(`Navigating to ${this.url}...`);
    await page.goto(this.url);

    // Wait for the body[data-wc-domready] attribute to become "true"
    await page.waitForSelector('body[data-wc-domready="true"]');

    console.log("The body[data-wc-domready] attribute is now true.1");

    // Use the 'select' method to select an option by its value
    const optionValueToSelect = "01"; // Replace with the value of the option you want to select
    await page.select("select", optionValueToSelect);

    await page.$eval("form", (form) => form.submit());

    await page.waitForSelector('body[data-wc-domready="true"]');

    console.log("The body[data-wc-domready] attribute is now true.2");
    //   await page.select('select:nth-child(1)','2')
    await page.evaluate(() => {
      const [firstInp, secondInp, thirdInp] =
        document.getElementsByTagName("select");
      secondInp.value = "2";
    });

    await page.$eval("form", (form) => form.submit());

    await page.waitForSelector('body[data-wc-domready="true"]');
    await page.evaluate(() => {
      const [firstInp, secondInp, thirdInp] =
        document.getElementsByTagName("select");
      thirdInp.value = "PAK";
      const trn = document.getElementsByTagName("input")[2];
      const date = document.getElementsByTagName("input")[3];
      const checkbox = document.getElementsByTagName("input")[5];
      const docNum = document.getElementsByTagName("input")[4];
      trn.value = "EGOZ0SXMYS";
      date.value = "22 May 1998";
      checkbox.checked = "true";
      docNum.value = "GT1118151";
      const submit = document.getElementsByTagName("button")[3];
      submit.click();
    });

    await page.waitForSelector('body[data-wc-domready="true"]');
    console.log("The body[data-wc-domready] attribute is now true.3");
    // The promise resolves after navigation has finished
    let result;
    const message = await page.evaluate(() => {
      try {
        console.log("here");
        const message = document.querySelector(".wc-message").innerText;
        return message;
      } catch {
        return "agya....";
      }
    });
    // Clicking the link will indirectly cause a navigation
    
    const scrapedData = { message: message, result: "Ni aya" };
    const mailOptions = {
      from: "chnouman49@zohomail.com",
      to: "chnouman433@gmail.com",
      subject: scrapedData.result,
      text: message,
    };
    const check = `You do not have a current Australian visa. If you are in Australia, you must hold a valid visa for the duration of your stay and comply with conditions attached to your visa. If you don't have the right to remain in Australia, you are expected to depart. To extend your stay in Australia you need to apply for a Bridging visa E (BVE). In most cases, you can resolve your visa matter quickly and easily through the My visa is about to expire or has expired webpage.`;
    if (message === check) {
      console.log("Ni aya");
      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.error("Error sending email:", error);
          process.exit()
        } else {
          console.log("Email sent:", info.response);
          process.exit()
        }
      });
      ref
        .set(scrapedData)
        .then(() => {
          console.log("Data uploaded to Firebase RTDB successfully.");
        })
        .catch((error) => {
          console.error("Error uploading data to Firebase RTDB:", error);
        });
        
    } else {
      console.log("Agya");
      scrapedData.message = message;
      scrapedData.result = "Agya mubarak ho";
      mailOptions.subject = scrapedData.result;
      // Send the email
      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          console.error("Error sending email:", error);
          process.exit()
        } else {
          console.log("Email sent:", info.response);
          process.exit()
        }
      });
      ref
        .set(scrapedData)
        .then(() => {
          console.log("Data uploaded to Firebase RTDB successfully.");
        })
        .catch((error) => {
          console.error("Error uploading data to Firebase RTDB:", error);
        });
    }
    
  },

  // Continue with your scraping logic or interactions with the selected option
};

module.exports = scraperObject;
